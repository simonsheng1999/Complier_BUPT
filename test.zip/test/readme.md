- tixing.pas 
  输入、输出、四则运算
   整个程序分为三段:输入、计算、输出。程序中用a,b,h三个变量分别存放梯形的上、下底与高，S存放面积。 要而使用这些变量都要先说明，程序的执行部分中先输入上、下底与高，接着求面积S,最后输出结果S。

- iseven.pas
  if语句
  输入一个整数ａ，判断是否为偶数
  
- ifthen.pas
  then嵌套if，条件判断
  输入一个年号,判断它是否是闰年

- case.pas
  case分支

- forloop.pas
  for循环
  求N！＝1＊2＊3＊…＊N。 程序要先输入N，然后从1累乘到N

- whileloop.pas
  while循环
  求两个正整数m和n的最大公约数

- repeatloop.pas
  repeat-until（do-while循环）
  求两个正整数m和n的最大公约数

- array.pas
  数组读入输出
  读入10个数，并逆序输出

- multiarray.pas
  多维数组读入输出
  3阶矩阵转置
  如运行程序时的输入为:
  　　2□1□3←┘
  　　3□3□1←┘
  　　1□2□1←┘
  　　则程序的输出应是:
  　　2□3□1
  　　1□3□2
  　　3□1□1

- func.pas
  函数定义、调用
  输出以下一个图形:
  　　　 *
  　　　 **
  
  ​			 ***
  
- poinster_.pas
  指针
  输入两个整数，按从小到大打印出来。